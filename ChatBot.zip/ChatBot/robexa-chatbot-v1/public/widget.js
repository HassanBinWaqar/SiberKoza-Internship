(function () {
  // 1. Create iframe
  var iframe = document.createElement('iframe');
  iframe.src = 'http://localhost:5173/';
  iframe.style.position = 'fixed';
  iframe.style.bottom = '20px';
  iframe.style.right = '20px';
  iframe.style.width = '400px';
  iframe.style.height = '600px';
  iframe.style.border = 'none';
  iframe.style.zIndex = '9999';
  iframe.style.borderRadius = '12px'; // Optional: rounded corners
  // iframe.style.boxShadow = '0px 4px 12px rgba(0, 0, 0, 0.3)'; // Optional: shadow
  iframe.allow = 'clipboard-write; microphone;';

  // 2. Append to body
  document.body.appendChild(iframe);
})();
