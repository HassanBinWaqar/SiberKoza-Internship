// src/hooks/useChat.ts
import { useEffect, useState } from 'react';
import {
  fetchMessages,
  sendMessage as apiSendMessage,
} from '../services/chatApi';

interface Message {
  sender: 'bot' | 'user';
  text: string;
}

export function useChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false); // 🛠️ ADD this line

  useEffect(() => {
    const interval = setInterval(async () => {
      setIsTyping(true); // 🛠️ Show typing...
      const newMessages = await fetchMessages();
      setMessages((prev) => [...prev, ...newMessages]);
      setIsTyping(false); // 🛠️ Stop typing after new message arrives
    }, 5000); // Poll every 5 seconds

    return () => clearInterval(interval);
  }, []);

  const sendMessage = async (text: string) => {
    const userMessage = await apiSendMessage(text);
    setMessages((prev) => [...prev, userMessage]);
  };

  return { messages, sendMessage, isTyping }; // 🛠️ Also RETURN it
}
