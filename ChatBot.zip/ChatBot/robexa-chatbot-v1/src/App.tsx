import { useState } from 'react';
import ChatBox from './components/ChatBox';
import { AnimatePresence } from 'framer-motion';

export default function App() {
  const [isChatOpen, setIsChatOpen] = useState(false);

  const toggleChat = () => {
    setIsChatOpen((prev) => !prev);
  };

  return (
    <>
      {/* Floating Chat Button */}
      <button
        onClick={toggleChat}
        className='fixed bottom-6 right-6 bg-purple-600 hover:bg-purple-700 text-white rounded-full p-4 shadow-lg transition-all duration-300 z-50'
      >
        💬
      </button>

      {/* ChatBox */}
      <AnimatePresence>{isChatOpen && <ChatBox />}</AnimatePresence>
    </>
  );
}
