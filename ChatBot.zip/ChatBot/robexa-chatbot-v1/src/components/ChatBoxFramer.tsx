import { useState, useRef, useEffect } from 'react';
import { useChat } from '../hooks/useChat';
import MessageItem from './MessageItem';
import { motion } from 'framer-motion'; // 👈 Import Framer Motion

export default function ChatBoxFramer() {
  const { messages, sendMessage, isTyping } = useChat();
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const handleSend = () => {
    if (input.trim() !== '') {
      sendMessage(input);
      setInput('');
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50, scale: 0.8 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 50, scale: 0.8 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className='fixed bottom-24 right-6 w-80 h-[500px] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-purple-300'
    >
      {/* Header */}
      <div className='bg-gradient-to-r from-purple-500 to-indigo-600 text-white text-lg font-bold p-3'>
        Messages
      </div>

      {/* Messages */}
      <div className='flex-1 overflow-y-auto p-3 bg-purple-50 space-y-2'>
        {messages.map((msg, idx) => (
          <MessageItem key={idx} sender={msg.sender} text={msg.text} />
        ))}
        {isTyping && (
          <div className='text-purple-400 text-sm italic text-center animate-pulse'>
            Bot is typing...
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className='flex items-center p-2 border-t border-purple-300 bg-white'>
        <input
          type='text'
          placeholder='Type a message...'
          className='flex-1 p-2 rounded-full border border-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-400 text-black bg-purple-50 placeholder-purple-400'
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
        />
        <button
          onClick={handleSend}
          className='ml-2 p-2 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full text-white hover:scale-110 transition-transform'
        >
          ➤
        </button>
      </div>
    </motion.div>
  );
}
