import React from 'react';

interface MessageItemProps {
  sender: 'bot' | 'user';
  text: string;
}

export default function MessageItem({ sender, text }: MessageItemProps) {
  const isUser = sender === 'user';

  return (
    <div
      className={`flex items-end ${
        isUser ? 'justify-end' : 'justify-start'
      } gap-2`}
    >
      {!isUser && (
        <div className='flex-shrink-0 w-8 h-8 bg-blue-300 rounded-full flex items-center justify-center text-white font-bold'>
          🤖
        </div>
      )}

      <div
        className={`px-4 py-2 rounded-2xl max-w-xs shadow ${
          isUser ? 'bg-blue-500 text-black' : 'bg-white text-black'
        }`}
      >
        {text}
      </div>

      {isUser && (
        <div className='flex-shrink-0 w-8 h-8 bg-green-400 rounded-full flex items-center justify-center text-black font-bold'>
          👤
        </div>
      )}
    </div>
  );
}
