import React, { useState, useRef, useEffect } from 'react';
import { useChat } from '../hooks/useChat';
import MessageItem from './MessageItem';

export default function ChatBox() {
  const { messages, sendMessage, isTyping } = useChat();
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const handleSend = () => {
    if (input.trim() !== '') {
      sendMessage(input);
      setInput('');
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className='fixed bottom-24 right-6 w-96 h-[500px] '>
      <div className='m-4 bg-white border-2 border-purple-400 rounded-md flex flex-col overflow-hidden w-96 h-[500px]'>
        {/* Header */}
        <div className='bg-gradient-to-r from-purple-500 to-indigo-600 text-white text-center py-3 font-bold text-lg shadow-md border-b border-purple-300'>
          Messages
        </div>

        {/* Messages */}
        <div className='flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-br from-purple-50 to-white'>
          {messages.map((msg, idx) => (
            <MessageItem key={idx} sender={msg.sender} text={msg.text} />
          ))}
          {isTyping && (
            <div className='text-purple-400 text-sm italic text-center animate-pulse'>
              Bot is typing...
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className='p-3 bg-white flex items-center border-t border-purple-300'>
          <button className='bg-gradient-to-br from-purple-500 to-indigo-600 text-white rounded-full p-3 mr-2 hover:scale-110 transition-transform'>
            +
          </button>
          <input
            className='flex-1 border-2 text-black border-purple-300 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400 bg-purple-50 placeholder-purple-400'
            placeholder='Type a message...'
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          />
          <button
            className='bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-full p-3 ml-2 hover:scale-110 transition-transform'
            onClick={handleSend}
          >
            ➤
          </button>
        </div>
      </div>
    </div>
  );
}
