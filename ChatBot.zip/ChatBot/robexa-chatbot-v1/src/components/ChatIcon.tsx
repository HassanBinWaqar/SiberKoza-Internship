import React from 'react';

interface ChatIconProps {
  onClick: () => void;
}

export default function ChatIcon({ onClick }: ChatIconProps) {
  return (
    <button
      onClick={onClick}
      className='fixed bottom-6 right-6 bg-gradient-to-br from-blue-500 to-indigo-600 p-4 rounded-full shadow-2xl hover:scale-110 hover:rotate-12 transition-transform duration-300 text-white text-2xl'
    >
      💬
    </button>
  );
}
