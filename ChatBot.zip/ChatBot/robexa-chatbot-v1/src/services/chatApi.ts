// src/services/chatApi.ts

// Type for message
type Message = {
  sender: 'bot' | 'user';
  text: string;
};

// Dummy pool with correct types
const DUMMY_MESSAGES_POOL: Message[] = [
  { sender: 'bot', text: 'Hello! How can I assist you today?' },
  { sender: 'bot', text: 'Tell me about yourSelf' },
  { sender: 'bot', text: 'Sure, I can help with that.' },
  { sender: 'bot', text: 'Sooo...Tell me your Name First' },
  { sender: 'bot', text: 'my name is ChatBot' },
  { sender: 'bot', text: 'Let me check that for you.' },
  { sender: 'bot', text: 'Thank you for your patience!' },

];

// Simulate fetching messages
export async function fetchMessages(): Promise<Message[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const randomIndex = Math.floor(
        Math.random() * DUMMY_MESSAGES_POOL.length
      );
      resolve([DUMMY_MESSAGES_POOL[randomIndex]]);
    }, 1000);
  });
}

// Simulate sending a user message
export async function sendMessage(userMessage: string): Promise<Message> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ sender: 'user', text: userMessage });
    }, 500);
  });
}
