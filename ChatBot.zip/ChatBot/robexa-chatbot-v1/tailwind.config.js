const defaultTheme = require('tailwindcss/defaultTheme');

module.exports = {
  purge: false,
  content: [
    './index.html',
    './src/**/*.{html,js,jsx,ts,tsx}',
    './src/*.{html,js,jsx,ts,tsx}',
    './public/**/*.{html,js,jsx,ts,tsx}',
  ],
  theme: {
    screens: {
      xs: { min: '275px', max: '639px' },
      ...defaultTheme.screens,
      'between-1270-1300': { min: '1270px', max: '1300px' },
      'between-700-1145': { min: '700px', max: '1145px' },
      'between-1280-1510': { min: '1280px', max: '1510px' },
      'max-1180': { max: '1180px' },
    },
    spinner: (theme) => ({
      default: {
        color: '#000000',
      },
      white: {
        color: '#FFFFFF',
      },
    }),
    extend: {
      fontSize: {
        xxs: '10px',
      },
      fontFamily: {
        sans: ['Inter var', ...defaultTheme.fontFamily.sans],
      },
      animation: {
        marquee: 'marquee 105s linear infinite',
        marquee2: 'marquee2 105s linear infinite',
      },
      keyframes: {
        marquee: {
          '0%': { transform: 'translateX(0%)' },
          '100%': { transform: 'translateX(-100%)' },
        },
        marquee2: {
          '0%': { transform: 'translateX(100%)' },
          '100%': { transform: 'translateX(0%)' },
        },
      },
    },
  },
  variants: {
    extend: {
      visibility: ['group-hover'],
      zIndex: ['group-hover'],
    },
  },
  plugins: [
    // require("@tailwindcss/ui")({ layout: "sidebar" }),
    require('@tailwindcss/forms'),
    require('tailwindcss-spinner')(),
    require('@tailwindcss/typography'),
    require('@tailwindcss/line-clamp'),
  ],
};
