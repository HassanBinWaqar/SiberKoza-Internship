let x =10;
console.log(x);
//here we can restrict the a , b with only type number no other values entered here 
function add(a:number,b:number){
    return a+b;
}

let a=add(2,3);
console.log(a);
//add('2','3');

let num:number=10;
const user_name:string="Hassan";
console.log(num,user_name);
console.warn(num,user_name);