var x = 10;
console.log(x);
//here we can restrict the a , b with only type number no other values entered here 
function add(a, b) {
    return a + b;
}
var a = add(2, 3);
console.log(a);
//add('2','3');
var num = 10;
var user_name = "Hassan";
console.log(num, user_name);
console.warn(num, user_name);
